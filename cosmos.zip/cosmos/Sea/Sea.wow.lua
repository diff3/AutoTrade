--[[
--
--	Sea.wow
--
--	WoW specific object functions
--
--]]

Sea.wow = {
	-- Tooltip related functions
	tooltip	= {};

	-- Item related functions
	item = {};
};

