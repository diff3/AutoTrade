-- 	Cosmos_RegisterChatCommand ( "AUTOTRADE_BID", tempcarray, tempcfunc, "Shows my bids currently in progress", CSM_CHAINNONE );

function Cosmos_RegisterChatCommand()
  SLASH_AutoTrade1 = "/autotrade";
  SLASH_AutoTrade2 = "/at";
  SlashCmdList["AutoTrade"] = function (msg)

  cmd = msg;

    if cmd == "reload" then
      ReloadUI();
    elseif cmd == "autotrade" or cmd == "allauctions" then
      ToggleAutotrade("AutotradeAllAuctionsFrame");
    elseif cmd == "myauctions" then
      ToggleAutotrade("AutotradeMyAuctionsFrame");
    elseif cmd == "mybids" then
      ToggleAutotrade("AutotradeBidAuctionsFrame");
    elseif cmd == "help" then
      ChatFrame1:AddMessage( "AutoTrade: /autotrade [autotrade, allauctions, myauctions, mybids]" , 1.0, 1.0, 0.0, 1.0);
    else
      ToggleAutotrade("AutotradeMyAuctionsFrame");
    end
  end
end

function ToggleAutotrade()

end
